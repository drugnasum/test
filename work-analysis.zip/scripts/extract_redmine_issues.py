#!/usr/bin/env python3
"""
Redmine Issue Extractor — extract all issues assigned to a user in a project.

Usage:
    python extract_redmine_issues.py -p <project> -u <username>
    python extract_redmine_issues.py                     (interactive mode)

Environment:
    REDMINE_API_KEY — Redmine REST API access key (required)

Output:
    redmine.json — all matching issues with journals, attachments, and full fields
"""

import os
import sys
import json
import argparse
import re
from datetime import datetime, date

# ---------------------------------------------------------------------------
# Hard-coded Redmine server URL — change this to match your instance
# ---------------------------------------------------------------------------
REDMINE_URL = "https://redmine.example.com"

# ---------------------------------------------------------------------------
# Helper: JSON serialization for non-serializable types
# ---------------------------------------------------------------------------
def _json_default(obj):
    """Convert date / datetime objects to ISO-format strings."""
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


# ---------------------------------------------------------------------------
# HTTP helper — uses requests if available, otherwise falls back to urllib
# ---------------------------------------------------------------------------
def _http_request(method, endpoint, params=None):
    """Make an HTTP request to the Redmine API and return parsed JSON."""
    url = f"{REDMINE_URL.rstrip('/')}{endpoint}"
    headers = {
        "X-Redmine-API-Key": os.environ["REDMINE_API_KEY"],
        "Accept": "application/json",
    }

    try:
        import requests
    except ImportError:
        # -----------------------------------------------------------------
        # Fallback: standard-library urllib
        # -----------------------------------------------------------------
        import urllib.request
        import urllib.error
        import urllib.parse

        if params:
            query_string = urllib.parse.urlencode(params, doseq=True)
            url = f"{url}?{query_string}"

        req = urllib.request.Request(url, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(
                f"HTTP {exc.code} on {method} {url}\nResponse: {body}"
            ) from None
        except urllib.error.URLError as exc:
            raise RuntimeError(
                f"Network error connecting to {REDMINE_URL}: {exc.reason}"
            ) from None

    # ---------------------------------------------------------------------
    # Preferred path: requests library
    # ---------------------------------------------------------------------
    try:
        if method == "GET":
            resp = requests.get(url, headers=headers, params=params, timeout=30)
        elif method == "POST":
            resp = requests.post(url, headers=headers, json=params, timeout=30)
        else:
            resp = requests.request(method, url, headers=headers, json=params, timeout=30)

        if not resp.ok:
            raise RuntimeError(
                f"HTTP {resp.status_code} on {method} {url}\nResponse: {resp.text}"
            )
        return resp.json()
    except requests.exceptions.ConnectionError as exc:
        raise RuntimeError(f"Network error connecting to {REDMINE_URL}: {exc}") from None
    except requests.exceptions.Timeout:
        raise RuntimeError(f"Request timed out: {method} {url}") from None


# ---------------------------------------------------------------------------
# Core logic
# ---------------------------------------------------------------------------
def find_project_id(name):
    """
    Resolve a project name (identifier or display name) to its numeric ID.
    Searches all accessible projects and returns the first match.
    """
    print(f"  Searching for project '{name}' ...")
    data = _http_request("GET", "/projects.json", {"limit": 100})
    projects = data.get("projects", [])

    # Try exact match on identifier first, then on name, then substring
    for proj in projects:
        if proj.get("identifier", "").lower() == name.lower():
            return proj["id"]
    for proj in projects:
        if proj.get("name", "").lower() == name.lower():
            return proj["id"]
    for proj in projects:
        if name.lower() in proj.get("identifier", "").lower() or name.lower() in proj.get("name", "").lower():
            return proj["id"]

    raise SystemExit(
        f"Project '{name}' not found. Available projects:\n"
        + "\n".join(f"  - {p.get('identifier','?')}  ({p.get('name','?')})" for p in projects)
    )


def find_user_id(username):
    """
    Resolve a username (login) to its numeric ID.
    """
    print(f"  Searching for user '{username}' ...")
    data = _http_request("GET", "/users.json", {"limit": 100, "status": 1})  # status=1  -> active
    users = data.get("users", [])

    for user in users:
        if user.get("login", "").lower() == username.lower():
            return user["id"]

    # Broader search: try name match
    for user in users:
        if username.lower() in user.get("login", "").lower() or username.lower() in f"{user.get('firstname','')} {user.get('lastname','')}".lower():
            return user["id"]

    raise SystemExit(
        f"User '{username}' not found. Available users:\n"
        + "\n".join(f"  - {u.get('login','?')}  ({u.get('firstname','')} {u.get('lastname','')})" for u in users)
    )


def fetch_all_issues(project_id, assigned_to_id):
    """
    Fetch ALL issues (handling pagination) for the given project + assignee.
    Returns a list of issue dicts from the list endpoint.
    """
    issues = []
    offset = 0
    limit = 100  # Redmine default max per page

    while True:
        params = {
            "project_id": project_id,
            "assigned_to_id": assigned_to_id,
            "status_id": "*",  # include all statuses
            "limit": limit,
            "offset": offset,
            "sort": "id:asc",
        }
        data = _http_request("GET", "/issues.json", params)
        batch = data.get("issues", [])
        total_count = data.get("total_count", 0)

        if not batch:
            break

        issues.extend(batch)
        offset += len(batch)

        print(f"    Fetched {len(issues)} / {total_count} issues ...")
        if offset >= total_count:
            break

    return issues


def fetch_issue_detail(issue_id):
    """
    Fetch a single issue with journals (comments) and attachments included.
    Returns the full issue object.
    """
    params = {"include": "journals,attachments"}
    data = _http_request("GET", f"/issues/{issue_id}.json", params)
    return data.get("issue", data)


def _derive_key(subject):
    """Derive the 'key' field from subject. If subject starts with DI-<digits>,
    key = that prefix; otherwise key = subject."""
    if subject is None:
        return None
    match = re.match(r"(DI-\d+)", subject)
    if match:
        return match.group(1)
    return subject


def build_output(project_name, username, project_id, user_id, issues_basic):
    """
    For each issue, fetch its detail (journals + attachments) and build the
    final output list.
    """
    output_list = []

    for i, basic in enumerate(issues_basic, 1):
        issue_id = basic["id"]
        print(f"    [{i}/{len(issues_basic)}] Fetching details for issue #{issue_id} ...")
        try:
            detail = fetch_issue_detail(issue_id)
        except RuntimeError as exc:
            # If a single issue fails, record the error and continue
            detail = {
                **basic,
                "journals": [],
                "attachments": [],
                "_fetch_error": str(exc),
            }

        # Extract attachment filenames for convenience
        attachment_files = [att.get("filename", "") for att in detail.get("attachments", [])]

        # Normalize journals: keep id, user, notes, created_on, details
        journals_clean = []
        for j in detail.get("journals", []):
            journals_clean.append({
                "id": j.get("id"),
                "user": j.get("user", {}).get("name"),
                "notes": j.get("notes"),
                "created_on": j.get("created_on"),
                "details": j.get("details", []),
            })

        subject = detail.get("subject")

        issue_out = {
            "key": _derive_key(subject),
            "id": detail.get("id"),
            "subject": subject,
            "description": detail.get("description"),
            "status": detail.get("status", {}).get("name"),
            "priority": detail.get("priority", {}).get("name"),
            "author": detail.get("author", {}).get("name"),
            "assigned_to": detail.get("assigned_to", {}).get("name"),
            "category": detail.get("category", {}).get("name"),
            "fixed_version": detail.get("fixed_version", {}).get("name"),
            "tracker": detail.get("tracker", {}).get("name"),
            "start_date": detail.get("start_date"),
            "due_date": detail.get("due_date"),
            "done_ratio": detail.get("done_ratio"),
            "estimated_hours": detail.get("estimated_hours"),
            "spent_hours": detail.get("spent_hours"),
            "created_on": detail.get("created_on"),
            "updated_on": detail.get("updated_on"),
            "closed_on": detail.get("closed_on"),
            "custom_fields": detail.get("custom_fields", []),
            "is_private": detail.get("is_private"),
            "parent_id": detail.get("parent", {}).get("id") if isinstance(detail.get("parent"), dict) else None,
            "project": detail.get("project", {}).get("name"),
            "journals": journals_clean,
            "attachment_files": attachment_files,
        }

        output_list.append(issue_out)

    return output_list


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Extract Redmine issues assigned to a user from a project."
    )
    parser.add_argument("-p", "--project", help="Redmine project identifier or display name")
    parser.add_argument("-u", "--user", help="Redmine username (login)")
    parser.add_argument(
        "-o", "--output", default="redmine.json",
        help="Output file path (default: redmine.json)"
    )
    args = parser.parse_args()

    # --- Validate API key ---------------------------------------------------
    api_key = os.environ.get("REDMINE_API_KEY")
    if not api_key:
        print("ERROR: Environment variable REDMINE_API_KEY is not set.")
        print("  Set it before running:  $env:REDMINE_API_KEY='your-key-here'  (PowerShell)")
        print("  or:                     export REDMINE_API_KEY='your-key-here'  (Bash)")
        sys.exit(1)

    # --- Gather inputs (args or interactive) --------------------------------
    project_name = args.project
    username = args.user

    if not project_name:
        project_name = input("Project name: ").strip()
    if not username:
        username = input("Username: ").strip()

    if not project_name or not username:
        print("ERROR: Both project name and username are required.")
        sys.exit(1)

    # --- Resolve IDs --------------------------------------------------------
    print(f"Connecting to {REDMINE_URL} ...")
    try:
        # Quick connectivity check
        _http_request("GET", "/projects.json", {"limit": 1})
    except RuntimeError as exc:
        print(f"ERROR: Cannot reach Redmine server.\n  {exc}")
        sys.exit(1)

    try:
        project_id = find_project_id(project_name)
    except SystemExit:
        raise
    except Exception as exc:
        print(f"ERROR: Failed to resolve project '{project_name}': {exc}")
        sys.exit(1)

    try:
        user_id = find_user_id(username)
    except SystemExit:
        raise
    except Exception as exc:
        print(f"ERROR: Failed to resolve user '{username}': {exc}")
        sys.exit(1)

    print(f"  Project ID = {project_id}, User ID = {user_id}")

    # --- Fetch all issues ---------------------------------------------------
    print("Fetching issue list (paginated) ...")
    try:
        issues_basic = fetch_all_issues(project_id, user_id)
    except RuntimeError as exc:
        print(f"ERROR: Failed to fetch issues.\n  {exc}")
        sys.exit(1)

    if not issues_basic:
        print(f"No issues found assigned to '{username}' in project '{project_name}'.")
        # Still write an empty output so the caller can inspect
        with open(args.output, "w", encoding="utf-8") as fp:
            json.dump([], fp, indent=2, ensure_ascii=False, default=_json_default)
        print(f"Empty result written to {args.output}")
        return

    # --- Fetch details for each issue ---------------------------------------
    print(f"Fetching full details for {len(issues_basic)} issues ...")
    try:
        output = build_output(project_name, username, project_id, user_id, issues_basic)
    except Exception as exc:
        print(f"ERROR: {exc}")
        sys.exit(1)

    # --- Write output -------------------------------------------------------
    with open(args.output, "w", encoding="utf-8") as fp:
        json.dump(output, fp, indent=2, ensure_ascii=False, default=_json_default)

    print(f"\nDone. {len(output)} issues written to {args.output}")


if __name__ == "__main__":
    main()
