#!/usr/bin/env python3
"""
Git commit aggregator: extracts commits by specified users from specified branches,
aggregates by DI- key or commit message, and outputs merged statistics.

Usage:
    python git_commit_aggregator.py <repo_url> -u user1 user2 -b main dev
    python git_commit_aggregator.py <repo_url> -u user1@xx.com -b main --match-email
    python git_commit_aggregator.py <repo_url> -b main -u _dummy --list-authors
    python git_commit_aggregator.py . -u alice -b main --use-local  (skip clone)
"""

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from collections import defaultdict
from typing import Dict, List, Optional, Set


VERBOSE = False


def log_verbose(msg: str) -> None:
    if VERBOSE:
        print(f"[DEBUG] {msg}", file=sys.stderr)


def run_git(
    cmd: List[str],
    cwd: Optional[str] = None,
    suppress_warn: bool = False,
) -> str:
    log_verbose(f"  git {' '.join(cmd)}")
    result = subprocess.run(
        ["git"] + cmd,
        capture_output=True,
        text=True,
        cwd=cwd,
        encoding="utf-8",
        errors="replace",
    )
    stdout = result.stdout
    stderr = result.stderr.strip()
    if result.returncode != 0:
        if not suppress_warn:
            print(
                f"Warning: git {' '.join(cmd)} failed: {stderr}",
                file=sys.stderr,
            )
        return ""
    if VERBOSE and stdout.strip():
        preview = stdout.strip()[:500]
        log_verbose(f"  -> {preview}")
    return stdout


def clone_repo(repo_url: str, target_dir: str) -> None:
    print(f"Cloning {repo_url} into {target_dir} ...")
    output = run_git(["clone", "--bare", repo_url, target_dir])
    if not output and not os.path.exists(os.path.join(target_dir, "HEAD")):
        print(f"Error: failed to clone {repo_url}", file=sys.stderr)
        sys.exit(1)
    print("Clone complete.")


def resolve_branch_ref(repo_dir: str, branch: str) -> str:
    for ref_candidate in [
        f"refs/remotes/origin/{branch}",
        f"refs/heads/{branch}",
    ]:
        result = run_git(
            ["rev-parse", "--verify", "-q", ref_candidate],
            cwd=repo_dir,
            suppress_warn=True,
        ).strip()
        if result:
            log_verbose(f"Resolved branch '{branch}' -> '{ref_candidate}'")
            if ref_candidate.startswith("refs/remotes/"):
                return ref_candidate[len("refs/remotes/"):]
            elif ref_candidate.startswith("refs/heads/"):
                return ref_candidate[len("refs/heads/"):]
            return ref_candidate

    # final fallback: try raw branch name
    result = run_git(
        ["rev-parse", "--verify", "-q", branch],
        cwd=repo_dir,
        suppress_warn=True,
    ).strip()
    if result:
        log_verbose(f"Resolved branch '{branch}' -> '{branch}' (raw)")
        return branch

    log_verbose(f"Could not resolve branch '{branch}'")
    return ""


def list_all_authors(repo_dir: str, refs: List[str]) -> List[str]:
    authors_set: Set[str] = set()
    for ref in refs:
        output = run_git(
            ["log", ref, "--format=%an <%ae>"],
            cwd=repo_dir,
        )
        for line in output.strip().split("\n"):
            line = line.strip()
            if line:
                authors_set.add(line)
    return sorted(authors_set)


def get_commits_for_branch(
    repo_dir: str,
    branch: str,
    authors: List[str],
    match_email: bool,
) -> Set[str]:
    commit_shas: Set[str] = set()
    ref = resolve_branch_ref(repo_dir, branch)
    if not ref:
        print(f"Warning: branch '{branch}' not found, skipping.", file=sys.stderr)
        return commit_shas

    # First, get total commit count on branch for comparison
    total_log = run_git(
        ["log", ref, "--format=%H"],
        cwd=repo_dir,
    )
    total_commits = len([l for l in total_log.strip().split("\n") if l.strip()])
    log_verbose(f"Branch '{ref}' has {total_commits} total commits")

    for author in authors:
        if match_email:
            output = run_git(
                ["log", ref, "--format=%H%x00%ae"],
                cwd=repo_dir,
            )
            for line in output.strip().split("\n"):
                if not line.strip():
                    continue
                parts = line.split("\0")
                if len(parts) >= 2:
                    sha, email = parts[0].strip(), parts[1].strip().lower()
                    if author.lower() in email:
                        commit_shas.add(sha)
            log_verbose(
                f"  Author-email filter '{author}': matched {len(commit_shas)} commits"
            )
        else:
            output = run_git(
                ["log", ref, "--author", author, "--format=%H"],
                cwd=repo_dir,
            )
            count = 0
            for line in output.strip().split("\n"):
                sha = line.strip()
                if sha:
                    commit_shas.add(sha)
                    count += 1
            log_verbose(
                f"  Author filter '{author}': matched {count} commits"
            )

    return commit_shas


MERGE_PREFIX_RE = re.compile(
    r"^Merge\s+(pull\s+request|branch|remote-tracking\s+branch|tag|remote)\b",
    re.IGNORECASE,
)


def clean_merge_message(raw_message: str) -> str:
    """Strip the auto-generated first line from merge commit messages."""
    lines = raw_message.split("\n")
    if lines and MERGE_PREFIX_RE.match(lines[0]):
        meaningful = "\n".join(lines[1:]).strip()
        if meaningful:
            return meaningful
    return raw_message.strip()


def get_commit_info(repo_dir: str, commit_sha: str) -> Optional[Dict]:
    # Get full commit message (subject + body)
    raw_msg = run_git(
        ["log", "-1", "--format=%B", commit_sha], cwd=repo_dir
    ).strip()
    if not raw_msg:
        return None

    msg = clean_merge_message(raw_msg)

    author = run_git(
        ["log", "-1", "--format=%an <%ae>", commit_sha], cwd=repo_dir
    ).strip()
    numstat = run_git(
        ["show", "--format=", "--first-parent", "-m", "--numstat", commit_sha],
        cwd=repo_dir,
    )

    files: List[str] = []
    additions = 0
    deletions = 0

    for line in numstat.strip().split("\n"):
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) >= 3:
            added_str, deleted_str, filename = parts[0], parts[1], parts[2]
            if added_str != "-" and deleted_str != "-":
                if not filename.lower().endswith(".pdd"):
                    additions += int(added_str)
                    deletions += int(deleted_str)
            files.append(filename)

    return {
        "commit_id": commit_sha,
        "author": author,
        "comment": msg,
        "files": files,
        "total_changes": additions + deletions,
        "additions": additions,
        "deletions": deletions,
    }


def extract_key(comment: str) -> str:
    # Extract the first line of cleaned comment for key matching
    first_line = comment.split("\n")[0].strip()
    match = re.match(r"(DI-\d+)", first_line)
    if match:
        return match.group(1)
    return first_line


def sanitize_dirname(name: str) -> str:
    """Convert a string to a safe directory name."""
    safe = re.sub(r'[<>:"/\\|?*\r\n]', "_", name).strip()
    return safe if safe else "_"


def git_show_file(repo_dir: str, ref_spec: str) -> Optional[bytes]:
    """Return file content at a git ref, or None if the file doesn't exist."""
    result = subprocess.run(
        ["git", "show", ref_spec],
        capture_output=True,
        cwd=repo_dir,
    )
    if result.returncode != 0:
        return None
    return result.stdout


def extract_diffs_for_group(
    repo_dir: str,
    diff_base: str,
    key: str,
    commit_file_map: Dict[str, List[str]],
    commit_ids: List[str],
) -> str:
    """Extract before/after file versions for all commits in a group."""
    safe_key = sanitize_dirname(key)
    group_dir = os.path.join(diff_base, safe_key)
    os.makedirs(group_dir, exist_ok=True)

    for sha in commit_ids:
        short = sha[:8]
        files = commit_file_map.get(sha, [])
        if not files:
            continue

        before_dir = os.path.join(group_dir, short, "before")
        after_dir = os.path.join(group_dir, short, "after")
        os.makedirs(before_dir, exist_ok=True)
        os.makedirs(after_dir, exist_ok=True)

        for filepath in files:
            safe_path = filepath.replace("/", os.sep)
            before_path = os.path.join(before_dir, safe_path)
            after_path = os.path.join(after_dir, safe_path)

            # Before-commit version (parent)
            before_content = git_show_file(repo_dir, f"{sha}^:{filepath}")
            if before_content is not None:
                os.makedirs(os.path.dirname(before_path), exist_ok=True)
                with open(before_path, "wb") as f:
                    f.write(before_content)

            # After-commit version
            after_content = git_show_file(repo_dir, f"{sha}:{filepath}")
            if after_content is not None:
                os.makedirs(os.path.dirname(after_path), exist_ok=True)
                with open(after_path, "wb") as f:
                    f.write(after_content)

    return os.path.abspath(group_dir)


def main() -> None:
    global VERBOSE

    parser = argparse.ArgumentParser(
        description="Aggregate git commits by users and branches"
    )
    parser.add_argument("repo_url", help="Git repository URL or local path")
    parser.add_argument(
        "--users",
        "-u",
        nargs="+",
        required=True,
        help="Author names (or emails with --match-email) to filter commits",
    )
    parser.add_argument(
        "--branches",
        "-b",
        nargs="+",
        required=True,
        help="Branches to analyze",
    )
    parser.add_argument(
        "--match-email",
        action="store_true",
        help="Match --users values against author email instead of author name",
    )
    parser.add_argument(
        "--list-authors",
        action="store_true",
        help="List all unique authors in the specified branches and exit",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Print debug information",
    )
    parser.add_argument(
        "--use-local",
        action="store_true",
        help="Use repo_url as an existing bare/non-bare repo directory (skip clone)",
    )
    parser.add_argument(
        "--diff-threshold",
        type=int,
        default=30,
        help="Extract before/after file versions when total_changes exceeds this (default: 50)",
    )
    parser.add_argument(
        "--diff-dir",
        default=None,
        help="Directory to store extracted diffs (default: <output_dir>/diffs)",
    )
    parser.add_argument(
        "--output-temp",
        default="output_temp.json",
        help="Temporary output file (default: output_temp.json)",
    )
    parser.add_argument(
        "--output",
        "-o",
        default="output.json",
        help="Final output file (default: output.json)",
    )
    parser.add_argument(
        "--repo-dir",
        help="Existing bare repo directory (skip clone). Deprecated, use --use-local.",
    )
    args = parser.parse_args()

    VERBOSE = args.verbose

    temp_dir: Optional[str] = None
    repo_dir = args.repo_dir or (args.repo_url if args.use_local else None)

    if not repo_dir:
        temp_dir = tempfile.mkdtemp(prefix="git_agg_")
        repo_dir = temp_dir
        clone_repo(args.repo_url, repo_dir)

    log_verbose(f"Using repo directory: {repo_dir}")

    # Resolve branch refs
    resolved_refs: List[str] = []
    for branch in args.branches:
        ref = resolve_branch_ref(repo_dir, branch)
        if ref:
            resolved_refs.append(ref)
        else:
            print(f"Warning: branch '{branch}' not found.", file=sys.stderr)

    if not resolved_refs:
        print(
            "Error: no valid branches found. "
            "Use --verbose to see which refs were probed.",
            file=sys.stderr,
        )
        if temp_dir:
            shutil.rmtree(temp_dir, ignore_errors=True)
        sys.exit(1)

    # --list-authors mode
    if args.list_authors:
        authors = list_all_authors(repo_dir, resolved_refs)
        print(
            f"\nAll authors across branches {args.branches}: "
            f"({len(authors)} total)\n"
        )
        for a in authors:
            print(f"  {a}")
        if temp_dir:
            shutil.rmtree(temp_dir, ignore_errors=True)
        return

    # Step 1: Collect all unique commits across branches and authors
    all_commit_shas: Set[str] = set()

    for branch in args.branches:
        print(f"Scanning branch: {branch}")
        shas = get_commits_for_branch(
            repo_dir, branch, args.users, args.match_email
        )
        all_commit_shas.update(shas)
        print(f"  Matched {len(shas)} commits on this branch")

    print(f"\nTotal unique commits across all branches: {len(all_commit_shas)}")

    if not all_commit_shas:
        print("\nNo commits found matching the specified users.", file=sys.stderr)
        print(
            "Troubleshooting:\n"
            "  1. Run with --list-authors to see actual author names in the repo\n"
            "  2. Try --match-email if your --users values are email addresses\n"
            "  3. Use --verbose to see the git commands being executed",
            file=sys.stderr,
        )
        if temp_dir:
            shutil.rmtree(temp_dir, ignore_errors=True)
        return

    # Step 2: Fetch stats for each unique commit
    commits_data: List[Dict] = []
    for i, sha in enumerate(sorted(all_commit_shas), 1):
        info = get_commit_info(repo_dir, sha)
        if info is None:
            print(f"  [{i}/{len(all_commit_shas)}] {sha[:8]} - SKIPPED (no data)")
            continue
        commits_data.append(info)
        print(
            f"  [{i}/{len(all_commit_shas)}] {sha[:8]} "
            f"{info['author']} - {info['comment'][:50]}"
        )

    # Write intermediate output
    with open(args.output_temp, "w", encoding="utf-8") as f:
        json.dump(commits_data, f, ensure_ascii=False, indent=2)
    print(f"\nIntermediate result saved to {args.output_temp}")

    # Step 3: Group by key (DI-xxx or full comment) and merge
    grouped: Dict[str, Dict] = defaultdict(
        lambda: {
            "key": "",
            "commit_ids": [],
            "comments": [],
            "files": set(),
            "total_changes": 0,
            "additions": 0,
            "deletions": 0,
        }
    )

    for commit in commits_data:
        key = extract_key(commit["comment"])
        grouped[key]["key"] = key
        grouped[key]["commit_ids"].append(commit["commit_id"])
        grouped[key]["comments"].append(commit["comment"])
        grouped[key]["files"].update(commit["files"])
        grouped[key]["total_changes"] += commit["total_changes"]
        grouped[key]["additions"] += commit["additions"]
        grouped[key]["deletions"] += commit["deletions"]

    # Build per-commit file map for diff extraction
    commit_file_map: Dict[str, List[str]] = {}
    for c in commits_data:
        commit_file_map[c["commit_id"]] = c["files"]

    result = []
    for key, data in grouped.items():
        result.append(
            {
                "key": key,
                "commit_ids": sorted(data["commit_ids"]),
                "comments": data["comments"],
                "files": sorted(data["files"]),
                "total_changes": data["total_changes"],
                "additions": data["additions"],
                "deletions": data["deletions"],
            }
        )

    # Step 4: Extract diffs for groups exceeding the threshold
    diff_dir = args.diff_dir or os.path.join(
        os.path.dirname(os.path.abspath(args.output)), "diffs"
    )
    threshold = args.diff_threshold
    diff_count = 0

    for group in result:
        total = group["total_changes"]
        if total <= threshold:
            continue
        print(
            f"Extracting diffs for '{group['key']}' ({total} lines changed, "
            f"{len(group['commit_ids'])} commits)"
        )
        diff_path = extract_diffs_for_group(
            repo_dir,
            diff_dir,
            group["key"],
            commit_file_map,
            group["commit_ids"],
        )
        group["diffPath"] = diff_path
        diff_count += 1

    result.sort(key=lambda x: x["key"])

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(
        f"Merged result saved to {args.output}  ({len(result)} groups"
        + (f", {diff_count} diffs extracted)" if diff_count else ")")
    )

    if temp_dir:
        shutil.rmtree(temp_dir, ignore_errors=True)


if __name__ == "__main__":
    main()
