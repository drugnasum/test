---
name: work-analysis
description: Professional work analysis over a specified period. Use this skill whenever the user asks for a work report, productivity analysis, commit analysis, developer activity summary, sprint review, performance evaluation, or wants to analyze someone's contributions and task history. This skill fetches git commits and Redmine tasks in parallel, then produces a detailed markdown report with complexity metrics, tables, and actionable insights.
---

# Work Analysis

Generate a professional analysis of a developer's work by combining git commit history with Redmine task data.

**Language: All reports must be written in Simplified Chinese (简体中文).** Only technical identifiers (file paths, commit hashes, DI-xxxx keys, variable names) should remain in English. All headings, analysis text, table labels, summaries, and observations must be in Chinese.

## Workflow overview

1. **Phase 1:** Run two data-collection scripts in parallel via subagents
2. **Phase 2:** Analyze the collected data across four complexity metrics
3. **Phase 3:** Check attachment compliance (diff / UT report / CodeReview report)
4. **Output:** Write a markdown report with summary, tables, and detailed analysis

## Phase 1: Parallel data collection

Before starting, gather these parameters from the user if not already provided:
- **Git repo URL** (or local path)
- **Username(s)** to analyze (author name or email)
- **Branch(es)** to scan (e.g., `main`, `develop`)
- **Redmine project** identifier
- **Redmine username** (login)
- **Time period** (optional — the scripts collect all available history by default; note the period in the report)

### Task 1.1 — Git commit aggregation

Spawn a subagent to run the script `scripts/git_commit_aggregator.py`. This script clones the repo, scans the specified branches for commits by the given user(s), groups commits by key (DI-xxxx or commit message), and extracts before/after file diffs for high-churn groups.

```
python scripts/git_commit_aggregator.py <repo_url> -u <user1> -b <branch1> <branch2> -o output.json --verbose
```

Key flags:
- `-u` / `--users`: author names (use `--match-email` if providing email addresses)
- `-b` / `--branches`: branches to scan
- `-o` / `--output`: output path, fixed to `output.json` in the current workspace
- `--use-local`: skip clone if repo_url is an existing local repo
- `--diff-threshold`: minimum total_changes to extract diffs (default: 30)

The script produces `output.json` (in the workspace directory) — an array of grouped commit objects with:
- `key`: DI-xxxx identifier or commit message first line
- `commit_ids`, `comments`, `files`, `total_changes`, `additions`, `deletions`
- `diffPath`: path to before/after file versions (only for commits exceeding the diff threshold)

### Task 1.2 — Redmine task extraction

In parallel with Task 1.1, spawn a subagent to run `scripts/extract_redmine_issues.py`. This script queries the Redmine REST API for all issues assigned to the specified user in the given project, including journals (update history) and attachments.

```
python scripts/extract_redmine_issues.py -p <project_name> -u <redmine_username> -o redmine.json
```

Requires: `REDMINE_API_KEY` environment variable must be set.

The script produces `redmine.json` — an array of issue objects with:
- `key`: DI-xxxx identifier or subject line
- `id`, `subject`, `description`, `status`, `priority`, `tracker`
- `journals`: array of update entries with `user`, `notes`, `created_on`, `details`
- `attachment_files`: array of attachment filenames
- `estimated_hours`, `spent_hours`, `done_ratio`, dates, custom fields

### Error handling during data collection

If a script fails (network error, missing credentials, empty results), note the failure in the report under a dedicated "Data Collection Notes" section and proceed with whatever data is available. A partial report is more useful than no report.

## Phase 2: Analysis

Once both output files are available, read them and perform the following analysis. For each commit group (from `output.json`), evaluate four complexity metrics. Cross-reference with `redmine.json` using the `key` field where both exist.

### Metric A: 代码变更量 / Code Churn (Lines of Code)

**评估内容：** 每个提交组的总变更行数（`total_changes`）。变更量越大，通常意味着变更风险越高。

**评分标准：**
- 低（≤50 行）：小型聚焦变更，通常为 bug 修复或小调整
- 中（51–200 行）：中等规模的功能开发或重构
- 高（201–500 行）：大型功能或多文件重构
- 极高（>500 行）：架构级变更、重大功能或累积的技术债务

### Metric B: 结构复杂度 / Structural Complexity (Diff Path Analysis)

**评估内容：** 对于包含 `diffPath` 字段的提交组，检查 before/after 文件版本。评估变更是否具有架构意义——是否增加耦合、引入复杂逻辑、跨模块边界或触及核心基础设施。

**执行方式：使用 SubAgent 进行分析。** 由于 diff 文件数量可能较多、内容较长，应将所有包含 `diffPath` 的提交组的 diff 分析工作委托给一个独立的 SubAgent 执行，避免占用主上下文。

**SubAgent 输入：**
- 从 `output.json` 中提取所有包含 `diffPath` 字段的条目（提交组的 key、commit_ids、files、diffPath）
- 提供以下评分准则供 SubAgent 参考

**分析方法（SubAgent 执行）：** 读取每个 diffPath 目录下的 before/after 文件样本。关注：
- 跨模块变更（不相关目录中的文件被同时修改）
- 引入新的抽象层或接口
- 源代码变更同时涉及配置、构建或部署文件
- 大量新增逻辑 vs. 机械性重构
- 测试文件与源代码同步变更（表明代码有测试覆盖，是正面信号）

**SubAgent 输出格式：** 对每个包含 diffPath 的任务返回：
```
任务: <key>
diffPath: <path>
评分: 极低/简单/中等/复杂/架构级
关键观察:
  - <观察点1>
  - <观察点2>
```

**评分标准（SubAgent 参考）：**
- 极低：表面变更、拼写修正、配置微调
- 简单：单文件变更、逻辑直接
- 中等：同模块内多文件变更、中等复杂度逻辑
- 复杂：跨模块变更、引入新模式、逻辑复杂
- 架构级：核心基础设施变更、API 设计、模块重组

SubAgent 完成后，将其返回的结果整合到报告的详细分析章节中。

### Metric C: 任务修订频率 / Task Revision Frequency (Diff Count)

**评估内容：** 如果存在匹配的 Redmine 任务（通过 `key` 字段匹配），统计 `attachment_files` 中带有 "diff" 前缀的文件数量。这些代表修订轮次——开发者提交更新补丁供审查的次数。数量较高可能意味着迭代改进或变更难度较大。

**评分标准：**
- 0 次修订：单次提交，任务直接
- 1-2 次修订：轻微迭代，正常的审查反馈
- 3-5 次修订：重大返工或需求变化
- 6+ 次修订：复杂任务、需求不明确或审查过程艰难

### Metric D: 更新历史复杂度 / Update History Complexity (Journal Analysis)

**评估内容：** 对于匹配的 Redmine 任务，检查 `journals` 数组。关注条目数量及其内容——备注、状态变更、重新分配。排查或返工的迹象包括：
- 多次状态变更（如重新打开、多次"进行中"→"已解决"循环）
- 备注中存在长篇讨论
- 重新分配给其他开发人员
- 提及阻塞问题、回滚或紧急修复

**评分标准：**
- 简单：≤5 条日志，线性推进
- 中等：6-15 条日志，有一定来回讨论
- 复杂：16-30 条日志，状态回退，详细技术讨论
- 高度复杂：>30 条日志，多次重新打开，跨团队协调

### Aggregated complexity summary (optional)

After scoring each metric for each commit/task, you may calculate an overall complexity level. Present this as a simple roll-up table rather than a numeric formula — the individual metrics are more informative than a combined score.

## Phase 3: 附件合规检查 / Attachment Compliance Check

遍历 `redmine.json` 中的所有任务，检查附件列表中是否同时包含以下三类文件。此检查仅在任务包含 diff 文件（文件名以 "diff" 开头，大小写不敏感）时执行。

**检查目标：**
- **Diff 文件：** 文件名以 "diff" 开头（如 `DI-4821_v1.diff`、`DI-4821_v2.diff`）
- **UT 报告：** 文件名包含 "UT"、"unit"、"单元测试"、"test report" 等关键词（大小写不敏感）
- **CodeReview 报告：** 文件名包含 "CodeReview"、"CR"、"code review"、"代码审查"、"review report" 等关键词（大小写不敏感）

**检查逻辑：**
1. 遍历 `redmine.json` 的每个任务，检查 `attachment_files` 数组
2. 如果该任务的附件中**没有任何**以 "diff" 开头的文件，跳过该任务（不纳入统计）
3. 对于包含 diff 文件的任务，逐一检查是否存在 UT 报告和 CodeReview 报告
4. 统计结果：总任务数、包含 diff 的任务数、同时有 UT 报告的数量、同时有 CodeReview 报告的数量、两者都有的数量、两者都没有的数量

**输出要求：** 将检查结果输出到 `work_analysis_report.md` 中一个独立的「附件合规检查」章节，包含汇总统计表格和逐任务的详细清单表格。

## Output format

Write the report to `work_analysis_report.md`. **The entire report MUST be written in Chinese (Simplified Chinese / 简体中文).** All headings, labels, analysis text, summaries, and observations should be in Chinese. Only technical terms (file paths, variable names, commit hashes, DI-xxxx keys) may remain in English.

Use this structure:

```markdown
# 工作分析报告 — [用户名]
**分析周期：** [开始日期] 至 [结束日期]
**代码仓库：** [仓库名称/地址]
**Redmine 项目：** [项目名称]
**生成日期：** [日期]

---

## 执行摘要

1-2 段概述，涵盖：分析的提交总数、Redmine 任务总数、整体复杂度分布、观察到的关键主题，以及最值得注意的发现。

---

## 汇总表格

### 提交概览

| 序号 | 任务编号 | 提交次数 | 文件变更数 | 代码行数 (+/-) | 复杂度 | Redmine 状态 |
|------|----------|----------|------------|----------------|--------|--------------|
| 1    | DI-xxxx  | 3        | 12         | +450/-120      | 高     | 已关闭       |

### 复杂度分布

| 指标 | 低 | 中 | 高 | 极高 |
|------|----|----|----|------|
| A: 代码变更量   | 4 | 3 | 2 | 1 |
| B: 结构复杂度   | 5 | 2 | 2 | 1 |
| C: 修订轮次     | 6 | 3 | 1 | 0 |
| D: 更新历史     | 4 | 4 | 1 | 1 |

### 时间分布

| 周次 | 提交数 | 完成任务数 | 总代码变更行数 |
|------|--------|------------|----------------|
| ...  | ...    | ...        | ...            |

### 工时汇总

| 任务编号 | 类型 | 预估(h) | 实际(h) | 偏差 | 效率 |
|----------|------|---------|---------|------|------|
| ...      | ...  | ...     | ...     | ...  | ...  |

---

## 详细分析

### [任务编号] — [主题/标题]

**提交次数：** [数量]  |  **代码行数：** +[新增]/-[删除]  |  **Redmine：** [#编号]

**指标 A — 代码变更量（Code Churn）：** [评估及证据]

**指标 B — 结构复杂度（Structural Complexity）：** [基于 diff 文件对比的具体观察]

**指标 C — 任务修订频率（Revision Frequency）：** [diff 附件数量及解读]

**指标 D — 更新历史复杂度（Journal Complexity）：** [日志分析及关键观察]

**小结：** [2-3 句话综合四个指标的评估]

---

（对每个任务/提交组重复以上详细分析）

---

## 数据采集说明

[阶段一遇到的问题、缺失数据、脚本错误等]

## 综合观察与建议

[跨任务观察：共同主题、重复出现的挑战、优势领域、改进建议]

## 附件合规检查

### 合规统计汇总

| 指标 | 数量 | 占比 |
|------|------|------|
| 任务总数 | X | — |
| 包含 diff 文件的任务数 | X | X% |
| 同时有 UT 报告  | X | X% |
| 同时有 CodeReview 报告 | X | X% |
| 两者都有 | X | X% |
| 两者都没有 | X | X% |

### 逐任务附件检查

| 任务编号 | diff 文件 | UT 报告 | CodeReview 报告 | 合规状态 |
|----------|-----------|---------|-----------------|----------|
| DI-xxxx  | 有        | 有      | 无              | 缺少CR   |
| DI-xxxx  | 有        | 无      | 有              | 缺少UT   |
| DI-xxxx  | 有        | 有      | 有              | 完整     |
```

### Table formatting rules
- All tables must use proper markdown alignment with `|---|` separators
- Numbers in tables should be right-aligned where appropriate
- Use `+` and `-` prefixes for additions/deletions in the lines column

## Principles for analysis

- **证据优先，避免臆测。** 每个复杂度评级都应引用具体数据——行数、文件路径、日志条目、diff 观察。如果某项指标数据不足，明确说明而非猜测。
- **上下文很重要。** 500 行配置模板的变更与 500 行核心业务逻辑的变更不可同日而语。评分前先阅读实际文件内容和提交信息。
- **描述要具体。** 与其说"这个很复杂"，不如说"该变更涉及 4 个模块的 8 个文件，引入了一个新的缓存层，经历了 4 轮修订——表明设计在审查过程中发生了显著演变。"
- **优雅处理缺失数据。** 如果 `redmine.json` 缺失或为空，跳过指标 C 和 D 并注明缺口。如果某个条目没有 `diffPath`，跳过该条目的指标 B。
- **所有报告内容使用简体中文。** 标题、分析文本、表格标签均使用中文，仅保留技术标识符（文件路径、提交哈希、DI-xxxx 编号）为英文。
