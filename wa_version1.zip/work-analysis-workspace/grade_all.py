#!/usr/bin/env python3
"""Grade work-analysis eval outputs against assertions."""
import json
import os
import re
import sys

def grade_outputs(output_md_path, assertions, eval_metadata_path):
    """Grade a single output markdown file against assertions."""
    # Read the output
    if not os.path.exists(output_md_path):
        results = []
        for a in assertions:
            results.append({"text": a, "passed": False, "evidence": "Output file not found"})
        return _build_result(results)

    with open(output_md_path, 'r', encoding='utf-8') as f:
        content = f.read()

    results = []

    for assertion in assertions:
        passed = False
        evidence = ""

        if "Executive Summary" in assertion:
            passed = bool(re.search(r'(?i)#+\s*(Executive\s+Summary|执行摘要)', content))
            evidence = f"Executive Summary / 执行摘要 heading {'found' if passed else 'not found'} in report"

        elif "commit overview table" in assertion or "one or more well-formatted markdown tables" in assertion:
            # Check for markdown tables (| --- | pattern)
            tables = re.findall(r'\|[-| ]+\|', content)
            has_table = len(tables) > 0
            passed = has_table
            evidence = f"Found {len(tables)} markdown tables in report"

        elif "complexity breakdown table" in assertion.lower():
            # Look for complexity table with metric labels (Chinese or English)
            has_complexity = bool(re.search(r'(?i)复杂度|complexity', content))
            has_distribution = bool(re.search(r'(?i)(分布|breakdown|指标.*低.*中.*高)', content))
            passed = has_complexity or has_distribution
            evidence = f"Complexity/distribution table: {'found' if passed else 'not found'}"

        elif "detailed per-task analysis" in assertion.lower():
            # Count task/DI sections
            task_sections = len(re.findall(r'(?i)^###\s+DI-\d+', content, re.MULTILINE))
            if "at least 5" in assertion:
                passed = task_sections >= 5
            else:
                passed = task_sections >= 3
            evidence = f"Found {task_sections} per-task analysis sections"

        elif "evaluates code churn" in assertion.lower() or "code churn" in assertion.lower():
            # Look for code churn mentions with line counts (Chinese or English)
            churn_mentions = len(re.findall(r'(?i)(代码变更量|code\s*churn|Metric\s*A|lines?\s*changed)', content))
            has_line_counts = bool(re.search(r'\+\d+/-\d+', content))
            passed = churn_mentions >= 3 and has_line_counts
            evidence = f"Code churn references: {churn_mentions}, line counts present: {has_line_counts}"

        elif "cross-references" in assertion.lower() or "cross-reference" in assertion.lower():
            # Check for both Redmine and git references (Chinese or English)
            has_redmine = bool(re.search(r'(?i)redmine', content))
            has_git_or_commit = bool(re.search(r'(?i)(commit|git\s|提交)', content))
            has_journals = bool(re.search(r'(?i)(journal|attachment.*diff|revision|日志|修订|附件)', content))
            passed = has_redmine and has_git_or_commit and has_journals
            evidence = f"Redmine refs: {has_redmine}, git/commit refs: {has_git_or_commit}, journal/diff refs: {has_journals}"

        elif "DI-xxxx" in assertion.lower() or "DI-" in assertion:
            di_count = len(re.findall(r'DI-\d{4}', content))
            passed = di_count >= 3
            evidence = f"Found {di_count} DI-xxxx task key references"

        elif "valid markdown file" in assertion.lower():
            # Check for markdown elements
            has_headings = bool(re.search(r'^#', content, re.MULTILINE))
            passed = has_headings and content.strip() != ""
            evidence = f"Markdown heading present: {has_headings}, non-empty: {content.strip() != ''}"

        elif "all four metrics" in assertion.lower():
            # Check all four metric names (Chinese or English)
            metrics_found = []
            for metric_name in ['代码变更量|code churn', '结构复杂|structural', '修订|revision', '更新历史|journal|日志']:
                if re.search(rf'(?i){metric_name}', content):
                    metrics_found.append(metric_name)
            passed = len(metrics_found) >= 4
            evidence = f"Metrics found: {', '.join(metrics_found)} ({len(metrics_found)}/4)"

        elif "diff directories" in assertion.lower() or "structural complexity" in assertion.lower():
            has_diff_ref = bool(re.search(r'(?i)(diff.*(path|dir|folder)|before.*after|结构复杂|structural.*complex)', content))
            passed = has_diff_ref
            evidence = f"Diff directory / structural analysis references: {has_diff_ref}"

        else:
            # Generic: check assertion text appears in content
            keywords = assertion.lower().split()
            matches = sum(1 for kw in keywords if kw in content.lower())
            passed = matches >= len(keywords) * 0.5
            evidence = f"Keyword match: {matches}/{len(keywords)}"

        results.append({
            "text": assertion,
            "passed": passed,
            "evidence": evidence,
        })

    return _build_result(results)


def _build_result(results):
    passed_count = sum(1 for r in results if r["passed"])
    total = len(results)
    return {
        "expectations": results,
        "summary": {
            "passed": passed_count,
            "failed": total - passed_count,
            "total": total,
            "pass_rate": passed_count / total if total > 0 else 0.0,
        },
        "execution_metrics": {},
        "timing": {},
        "claims": [],
        "eval_feedback": {"suggestions": [], "overall": "Auto-graded via script"},
    }


def main():
    base = sys.argv[1] if len(sys.argv) > 1 else r"H:\test\work-analysis-workspace\iteration-1"
    evals = [
        ("eval-0-formal-report", "formal-report"),
        ("eval-1-casual-request", "casual-request"),
        ("eval-2-complexity-focus", "complexity-focus"),
    ]

    for eval_dir, eval_name in evals:
        # Load assertions from metadata
        meta_path = os.path.join(base, eval_dir, "eval_metadata.json")
        with open(meta_path, 'r', encoding='utf-8') as f:
            meta = json.load(f)
        assertions = meta["assertions"]

        for config in ["with_skill", "without_skill"]:
            output_md = os.path.join(base, eval_dir, config, "outputs", "work_analysis_report.md")
            if not os.path.exists(output_md):
                print(f"  Skipping {eval_dir}/{config} - no output file")
                continue
            grading_path = os.path.join(base, eval_dir, config, "grading.json")

            print(f"Grading {eval_dir}/{config}...")
            result = grade_outputs(output_md, assertions, meta_path)
            
            with open(grading_path, 'w', encoding='utf-8') as f:
                json.dump(result, f, indent=2, ensure_ascii=False)
            
            rate = result["summary"]["pass_rate"]
            print(f"  {result['summary']['passed']}/{result['summary']['total']} passed ({rate:.0%})")

if __name__ == "__main__":
    main()
