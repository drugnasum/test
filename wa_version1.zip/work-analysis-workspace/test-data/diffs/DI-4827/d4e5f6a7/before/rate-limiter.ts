// BEFORE: Rate limiter with race condition
export class RateLimiter {
  private windowStart: number = Date.now();
  private counter: number = 0;
  private limit: number;

  constructor(limit: number) {
    this.limit = limit;
  }

  allow(): boolean {
    const now = Date.now();
    if (now - this.windowStart > 60000) {
      this.windowStart = now;
      this.counter = 0;
    }
    if (this.counter >= this.limit) {
      return false;
    }
    this.counter++;
    return true;
  }
}
