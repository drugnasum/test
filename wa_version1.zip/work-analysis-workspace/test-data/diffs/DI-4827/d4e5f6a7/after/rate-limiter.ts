// AFTER: Rate limiter with atomic counter (race condition fixed)
export class RateLimiter {
  private windowStart: number = Date.now();
  private counter: number = 0;
  private limit: number;
  private pending: Map<string, Promise<boolean>> = new Map();

  constructor(limit: number) {
    this.limit = limit;
  }

  async allow(requestId: string): Promise<boolean> {
    // Prevents concurrent checks on same request
    if (this.pending.has(requestId)) {
      return this.pending.get(requestId)!;
    }
    const promise = this._check();
    this.pending.set(requestId, promise);
    const result = await promise;
    this.pending.delete(requestId);
    return result;
  }

  private async _check(): Promise<boolean> {
    const now = Date.now();
    // Atomic window reset with compare-and-swap pattern
    if (now - this.windowStart > 60000) {
      this.windowStart = now;
      this.counter = 0;
    }
    if (this.counter >= this.limit) {
      return false;
    }
    this.counter++;
    return true;
  }
}
