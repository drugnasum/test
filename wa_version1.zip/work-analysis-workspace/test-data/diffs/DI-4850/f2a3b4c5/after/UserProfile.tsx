// AFTER: UserProfile.tsx - uses shared date-format utility
import { formatDate, relativeTime } from '@/utils/date-format';

export function UserProfile({ user }: { user: any }) {
  const joinedDate = formatDate(user.joinedAt, 'long');
  const lastLogin = relativeTime(user.lastLogin);
  return (
    <div>
      <p>Member since: {joinedDate}</p>
      <p>Last seen: {lastLogin}</p>
    </div>
  );
}
