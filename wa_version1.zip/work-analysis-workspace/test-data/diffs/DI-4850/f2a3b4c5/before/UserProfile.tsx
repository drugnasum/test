// BEFORE: UserProfile.tsx - uses moment.js directly
import moment from 'moment';

export function UserProfile({ user }: { user: any }) {
  const joinedDate = moment(user.joinedAt).format('MMMM Do, YYYY');
  const lastLogin = moment(user.lastLogin).fromNow();
  return (
    <div>
      <p>Member since: {joinedDate}</p>
      <p>Last seen: {lastLogin}</p>
    </div>
  );
}
