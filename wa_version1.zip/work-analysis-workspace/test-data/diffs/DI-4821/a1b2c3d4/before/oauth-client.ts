// BEFORE: oauth-client.ts - single file, basic flow
import crypto from 'crypto';

export class OAuthClient {
  private clientId: string;
  private clientSecret: string;
  private tokens: Map<string, { access: string; refresh: string }> = new Map();

  constructor(clientId: string, clientSecret: string) {
    this.clientId = clientId;
    this.clientSecret = clientSecret;
  }

  getAuthUrl(provider: string, redirectUri: string): string {
    const state = crypto.randomBytes(16).toString('hex');
    return `https://${provider}.com/oauth/authorize?` +
      `client_id=${this.clientId}&redirect_uri=${redirectUri}&state=${state}`;
  }

  async exchangeCode(code: string, provider: string): Promise<string> {
    const response = await fetch(`https://${provider}.com/oauth/token`, {
      method: 'POST',
      body: JSON.stringify({ code, client_id: this.clientId, client_secret: this.clientSecret }),
    });
    const data = await response.json();
    this.tokens.set(provider, { access: data.access_token, refresh: data.refresh_token });
    return data.access_token;
  }

  getToken(provider: string): string | undefined {
    return this.tokens.get(provider)?.access;
  }
}
