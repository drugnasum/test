// AFTER: oauth-client.ts - PKCE flow, separated concerns, typed
import crypto from 'crypto';
import { TokenStore } from './token-store';
import { OAuthConfig, TokenResponse, OAuthProvider } from './types';

export class OAuthClient {
  private config: OAuthConfig;
  private tokenStore: TokenStore;

  constructor(config: OAuthConfig, tokenStore: TokenStore) {
    this.config = config;
    this.tokenStore = tokenStore;
  }

  getAuthUrl(provider: OAuthProvider, redirectUri: string): { url: string; codeVerifier: string } {
    const codeVerifier = crypto.randomBytes(32).toString('base64url');
    const codeChallenge = crypto
      .createHash('sha256')
      .update(codeVerifier)
      .digest('base64url');
    const state = crypto.randomBytes(16).toString('hex');

    const url = `https://${provider}.com/oauth/authorize?` +
      `client_id=${this.config.clientId}` +
      `&redirect_uri=${encodeURIComponent(redirectUri)}` +
      `&state=${state}` +
      `&code_challenge=${codeChallenge}` +
      `&code_challenge_method=S256` +
      `&response_type=code`;

    return { url, codeVerifier };
  }

  async exchangeCode(
    code: string,
    codeVerifier: string,
    provider: OAuthProvider,
  ): Promise<TokenResponse> {
    const response = await fetch(`https://${provider}.com/oauth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: this.config.clientId,
        code_verifier: codeVerifier,
        grant_type: 'authorization_code',
      }),
    });

    if (!response.ok) {
      throw new Error(`OAuth token exchange failed: ${response.status}`);
    }

    const data: TokenResponse = await response.json();
    await this.tokenStore.save(provider, data);
    return data;
  }

  async getValidToken(provider: OAuthProvider): Promise<string> {
    const tokens = await this.tokenStore.get(provider);
    if (!tokens) {
      throw new Error(`No tokens found for provider: ${provider}`);
    }
    if (this.isExpired(tokens.accessToken)) {
      return this.refreshToken(provider, tokens.refreshToken);
    }
    return tokens.accessToken;
  }

  private async refreshToken(provider: OAuthProvider, refreshToken: string): Promise<string> {
    const response = await fetch(`https://${provider}.com/oauth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        refresh_token: refreshToken,
        client_id: this.config.clientId,
        grant_type: 'refresh_token',
      }),
    });

    if (response.status === 401) {
      await this.tokenStore.invalidate(provider);
      throw new Error('Refresh token expired or revoked');
    }

    const data = await response.json();
    await this.tokenStore.save(provider, data);
    return data.access_token;
  }

  private isExpired(token: string): boolean {
    try {
      const payload = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString());
      return payload.exp * 1000 < Date.now();
    } catch {
      return true;
    }
  }
}
