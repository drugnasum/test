#!/usr/bin/env python3
"""
Git commit aggregator: extracts commits by specified users from specified branches,
aggregates by DI- key or commit message, and outputs merged statistics.

Usage:
    python git_commit_aggregator.py <repo_url> -u user1 user2 -b main dev
    python git_commit_aggregator.py <repo_url> -u user1@xx.com -b main --match-email
    python git_commit_aggregator.py <repo_url> -b main -u _dummy --list-authors
    python git_commit_aggregator.py . -u alice -b main --use-local  (skip clone)
    python git_commit_aggregator.py --config repos.json
"""

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from collections import defaultdict
from typing import Dict, List, Optional, Set


VERBOSE = False

# Git retry configuration
GIT_MAX_RETRIES = 3
GIT_RETRY_DELAY = 3  # seconds, exponential backoff base


def log_verbose(msg: str) -> None:
    if VERBOSE:
        print(f"[DEBUG] {msg}", file=sys.stderr)


def run_git(
    cmd: List[str],
    cwd: Optional[str] = None,
    suppress_warn: bool = False,
    retries: int = GIT_MAX_RETRIES,
) -> str:
    log_verbose(f"  git {' '.join(cmd)}")
    last_error = None
    for attempt in range(1, retries + 1):
        result = subprocess.run(
            ["git"] + cmd,
            capture_output=True,
            text=True,
            cwd=cwd,
            encoding="utf-8",
            errors="replace",
        )
        stdout = result.stdout
        stderr = result.stderr.strip()
        if result.returncode == 0:
            if VERBOSE and stdout.strip():
                preview = stdout.strip()[:500]
                log_verbose(f"  -> {preview}")
            return stdout
        last_error = stderr
        # Don't retry on non-network errors for most commands
        if not suppress_warn and attempt < retries:
            delay = GIT_RETRY_DELAY * (2 ** (attempt - 1))
            print(
                f"  [GIT RETRY {attempt}/{retries}] git {' '.join(cmd)} failed: {stderr[:200]}. Retrying in {delay}s...",
                file=sys.stderr,
            )
            time.sleep(delay)

    if not suppress_warn:
        print(
            f"Warning: git {' '.join(cmd)} failed after {retries} attempts: {last_error[:200]}",
            file=sys.stderr,
        )
    return ""


def clone_repo(repo_url: str, target_dir: str) -> None:
    print(f"Cloning {repo_url} into {target_dir} ...")
    # Check if directory already has a valid git repo (cache hit)
    if os.path.exists(os.path.join(target_dir, "HEAD")):
        print(f"  Using existing clone at {target_dir} (cached)")
        return
    last_error = None
    for attempt in range(1, GIT_MAX_RETRIES + 1):
        try:
            run_git(["clone", "--bare", repo_url, target_dir])
            if os.path.exists(os.path.join(target_dir, "HEAD")):
                print("Clone complete.")
                return
        except Exception as exc:
            last_error = exc
        if attempt < GIT_MAX_RETRIES:
            delay = GIT_RETRY_DELAY * (2 ** (attempt - 1))
            print(f"  [CLONE RETRY {attempt}/{GIT_MAX_RETRIES}] Failed: {last_error}. Retrying in {delay}s...")
            # Clean up partial clone
            shutil.rmtree(target_dir, ignore_errors=True)
            time.sleep(delay)
    print(f"Error: failed to clone {repo_url} after {GIT_MAX_RETRIES} attempts", file=sys.stderr)
    sys.exit(1)


def resolve_branch_ref(repo_dir: str, branch: str) -> str:
    for ref_candidate in [
        f"refs/remotes/origin/{branch}",
        f"refs/heads/{branch}",
    ]:
        result = run_git(
            ["rev-parse", "--verify", "-q", ref_candidate],
            cwd=repo_dir,
            suppress_warn=True,
        ).strip()
        if result:
            log_verbose(f"Resolved branch '{branch}' -> '{ref_candidate}'")
            if ref_candidate.startswith("refs/remotes/"):
                return ref_candidate[len("refs/remotes/"):]
            elif ref_candidate.startswith("refs/heads/"):
                return ref_candidate[len("refs/heads/"):]
            return ref_candidate

    # final fallback: try raw branch name
    result = run_git(
        ["rev-parse", "--verify", "-q", branch],
        cwd=repo_dir,
        suppress_warn=True,
    ).strip()
    if result:
        log_verbose(f"Resolved branch '{branch}' -> '{branch}' (raw)")
        return branch

    log_verbose(f"Could not resolve branch '{branch}'")
    return ""


def list_all_authors(repo_dir: str, refs: List[str]) -> List[str]:
    authors_set: Set[str] = set()
    for ref in refs:
        output = run_git(
            ["log", ref, "--format=%an <%ae>"],
            cwd=repo_dir,
        )
        for line in output.strip().split("\n"):
            line = line.strip()
            if line:
                authors_set.add(line)
    return sorted(authors_set)


def is_merge_or_pull_request_commit(repo_dir: str, commit_sha: str) -> bool:
    """Check if a commit is a merge or pull request commit."""
    subject = run_git(
        ["log", "-1", "--format=%s", commit_sha], cwd=repo_dir
    ).strip()
    
    if MERGE_PREFIX_RE.match(subject):
        return True
    
    if re.match(r"^Merge pull request", subject, re.IGNORECASE):
        return True
    
    if re.match(r"^Merge branch", subject, re.IGNORECASE):
        return True
    
    if re.match(r"^Merge remote-tracking branch", subject, re.IGNORECASE):
        return True
    
    if re.match(r"^Pull request", subject, re.IGNORECASE):
        return True
    
    parent_count = run_git(
        ["rev-list", "--parents", "-n", "1", commit_sha], cwd=repo_dir
    ).strip().split()
    if len(parent_count) > 2:
        return True
    
    return False


def get_commits_for_branch(
    repo_dir: str,
    branch: str,
    authors: List[str],
    match_email: bool,
) -> Set[str]:
    commit_shas: Set[str] = set()
    ref = resolve_branch_ref(repo_dir, branch)
    if not ref:
        print(f"Warning: branch '{branch}' not found, skipping.", file=sys.stderr)
        return commit_shas

    # First, get total commit count on branch for comparison
    total_log = run_git(
        ["log", ref, "--format=%H"],
        cwd=repo_dir,
    )
    total_commits = len([l for l in total_log.strip().split("\n") if l.strip()])
    log_verbose(f"Branch '{ref}' has {total_commits} total commits")

    for author in authors:
        if match_email:
            output = run_git(
                ["log", ref, "--format=%H%x00%ae"],
                cwd=repo_dir,
            )
            for line in output.strip().split("\n"):
                if not line.strip():
                    continue
                parts = line.split("\0")
                if len(parts) >= 2:
                    sha, email = parts[0].strip(), parts[1].strip().lower()
                    if author.lower() in email:
                        if not is_merge_or_pull_request_commit(repo_dir, sha):
                            commit_shas.add(sha)
            log_verbose(
                f"  Author-email filter '{author}': matched {len(commit_shas)} commits"
            )
        else:
            output = run_git(
                ["log", ref, "--author", author, "--format=%H"],
                cwd=repo_dir,
            )
            count = 0
            for line in output.strip().split("\n"):
                sha = line.strip()
                if sha:
                    if not is_merge_or_pull_request_commit(repo_dir, sha):
                        commit_shas.add(sha)
                        count += 1
            log_verbose(
                f"  Author filter '{author}': matched {count} commits"
            )

    return commit_shas


MERGE_PREFIX_RE = re.compile(
    r"^Merge\s+(pull\s+request|branch|remote-tracking\s+branch|tag|remote)\b",
    re.IGNORECASE,
)


def clean_merge_message(raw_message: str) -> str:
    """Strip the auto-generated first line from merge commit messages."""
    lines = raw_message.split("\n")
    if lines and MERGE_PREFIX_RE.match(lines[0]):
        meaningful = "\n".join(lines[1:]).strip()
        if meaningful:
            return meaningful
    return raw_message.strip()


def get_commit_info(repo_dir: str, commit_sha: str) -> Optional[Dict]:
    # Get full commit message (subject + body)
    raw_msg = run_git(
        ["log", "-1", "--format=%B", commit_sha], cwd=repo_dir
    ).strip()
    if not raw_msg:
        return None

    msg = clean_merge_message(raw_msg)

    author = run_git(
        ["log", "-1", "--format=%an <%ae>", commit_sha], cwd=repo_dir
    ).strip()
    numstat = run_git(
        ["show", "--format=", "--first-parent", "-m", "--numstat", commit_sha],
        cwd=repo_dir,
    )

    files: List[str] = []
    additions = 0
    deletions = 0

    for line in numstat.strip().split("\n"):
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) >= 3:
            added_str, deleted_str, filename = parts[0], parts[1], parts[2]
            if added_str != "-" and deleted_str != "-":
                if not filename.lower().endswith(".pdd") and \
                    not filename.lower().endswith(".exe") and \
                    not filename.lower().endswith(".dll"):
                    additions += int(added_str)
                    deletions += int(deleted_str)
            files.append(filename)

    return {
        "commit_id": commit_sha,
        "author": author,
        "comment": msg,
        "files": files,
        "total_changes": additions + deletions,
        "additions": additions,
        "deletions": deletions,
    }


def extract_key(comment: str) -> str:
    # Extract the first line of cleaned comment for key matching
    first_line = comment.split("\n")[0].strip()
    # If commit starts with "Pull request #<number> :", ignore up to the colon
    m = re.match(r"^Pull\s+request\s+#\d+\s*:\s*(.*)", first_line, re.IGNORECASE)
    if m:
        first_line = m.group(1).strip()
    # If the remaining text starts with "Bugfix/" or "BUGFIX/", ignore that prefix
    first_line = re.sub(r"^(Bugfix|BUGFIX)\s*/\s*", "", first_line)
    match = re.match(r"(DI-\d+)", first_line)
    if match:
        return match.group(1)
    return first_line


def sanitize_dirname(name: str) -> str:
    """Convert a string to a safe directory name."""
    safe = re.sub(r'[<>:"/\\|?*\r\n]', "_", name).strip()
    return safe if safe else "_"


def git_show_file(repo_dir: str, ref_spec: str) -> Optional[bytes]:
    """Return file content at a git ref, or None if the file doesn't exist."""
    result = subprocess.run(
        ["git", "show", ref_spec],
        capture_output=True,
        cwd=repo_dir,
    )
    if result.returncode != 0:
        return None
    return result.stdout


def extract_diffs_for_group(
    repo_dir: str,
    diff_base: str,
    key: str,
    commit_file_map: Dict[str, List[str]],
    commit_ids: List[str],
) -> str:
    """Extract before/after file versions for all commits in a group."""
    safe_key = sanitize_dirname(key)
    group_dir = os.path.join(diff_base, safe_key)
    os.makedirs(group_dir, exist_ok=True)

    for sha in commit_ids:
        short = sha[:8]
        files = commit_file_map.get(sha, [])
        if not files:
            continue

        before_dir = os.path.join(group_dir, short, "before")
        after_dir = os.path.join(group_dir, short, "after")
        os.makedirs(before_dir, exist_ok=True)
        os.makedirs(after_dir, exist_ok=True)

        for filepath in files:
            safe_path = filepath.replace("/", os.sep)
            before_path = os.path.join(before_dir, safe_path)
            after_path = os.path.join(after_dir, safe_path)

            # Before-commit version (parent)
            before_content = git_show_file(repo_dir, f"{sha}^:{filepath}")
            if before_content is not None:
                os.makedirs(os.path.dirname(before_path), exist_ok=True)
                with open(before_path, "wb") as f:
                    f.write(before_content)

            # After-commit version
            after_content = git_show_file(repo_dir, f"{sha}:{filepath}")
            if after_content is not None:
                os.makedirs(os.path.dirname(after_path), exist_ok=True)
                with open(after_path, "wb") as f:
                    f.write(after_content)

    return os.path.abspath(group_dir)


def resolve_repo_dir(repo_url: str, use_local: bool, cache_dir: Optional[str], repo_dir_override: Optional[str] = None) -> str:
    """Resolve or clone a repo directory. Returns (repo_dir, temp_dir_or_none)."""
    temp_dir = None
    repo_dir = repo_dir_override or (repo_url if use_local else None)

    if not repo_dir:
        if cache_dir:
            os.makedirs(cache_dir, exist_ok=True)
            safe_url_hash = hashlib.sha256(repo_url.encode()).hexdigest()[:12]
            cached_repo_dir = os.path.join(cache_dir, safe_url_hash)
            if os.path.exists(os.path.join(cached_repo_dir, "HEAD")):
                repo_dir = cached_repo_dir
                print(f"  Using cached repo from {repo_dir}")
        if not repo_dir:
            temp_dir = tempfile.mkdtemp(prefix="git_agg_")
            if cache_dir:
                safe_url_hash = hashlib.sha256(repo_url.encode()).hexdigest()[:12]
                repo_dir = os.path.join(cache_dir, safe_url_hash)
                if not os.path.exists(os.path.join(repo_dir, "HEAD")):
                    clone_repo(repo_url, repo_dir)
            else:
                repo_dir = temp_dir
                clone_repo(repo_url, repo_dir)
    elif cache_dir:
        safe_url_hash = hashlib.sha256(repo_url.encode()).hexdigest()[:12]
        cached_repo_dir = os.path.join(cache_dir, safe_url_hash)
        if not os.path.exists(os.path.join(cached_repo_dir, "HEAD")):
            os.makedirs(cached_repo_dir, exist_ok=True)
            if os.path.isdir(repo_url):
                print(f"  Copying local repo to cache: {cached_repo_dir}")
                shutil.copytree(repo_url, cached_repo_dir, dirs_exist_ok=True)
                repo_dir = cached_repo_dir

    return repo_dir, temp_dir


def process_repo(
    repo_url: str,
    branches: List[str],
    users: List[str],
    match_email: bool,
    use_local: bool,
    diff_threshold: int,
    diff_dir: str,
    output_temp: str,
    cache_dir: Optional[str] = None,
    repo_dir_override: Optional[str] = None,
) -> List[Dict]:
    """
    Process a single repo: collect commits, group by key, extract diffs.
    Returns list of grouped commit dicts.
    """
    repo_dir, temp_dir = resolve_repo_dir(repo_url, use_local, cache_dir, repo_dir_override)
    log_verbose(f"Using repo directory: {repo_dir}")

    # Resolve branch refs
    resolved_refs: List[str] = []
    for branch in branches:
        ref = resolve_branch_ref(repo_dir, branch)
        if ref:
            resolved_refs.append(ref)
        else:
            print(f"Warning: branch '{branch}' not found.", file=sys.stderr)

    if not resolved_refs:
        print(
            f"Error: no valid branches found for repo '{repo_url}'. "
            "Use --verbose to see which refs were probed.",
            file=sys.stderr,
        )
        if temp_dir:
            shutil.rmtree(temp_dir, ignore_errors=True)
        return []

    # Step 1: Collect all unique commits across branches and authors
    all_commit_shas: Set[str] = set()

    for branch in branches:
        print(f"Scanning branch: {branch}")
        shas = get_commits_for_branch(
            repo_dir, branch, users, match_email
        )
        all_commit_shas.update(shas)
        print(f"  Matched {len(shas)} commits on this branch")

    print(f"\nTotal unique commits across all branches: {len(all_commit_shas)}")

    if not all_commit_shas:
        print("\nNo commits found matching the specified users.", file=sys.stderr)
        if temp_dir:
            shutil.rmtree(temp_dir, ignore_errors=True)
        return []

    # Step 2: Fetch stats for each unique commit
    commits_data: List[Dict] = []
    for i, sha in enumerate(sorted(all_commit_shas), 1):
        info = get_commit_info(repo_dir, sha)
        if info is None:
            print(f"  [{i}/{len(all_commit_shas)}] {sha[:8]} - SKIPPED (no data)")
            continue
        commits_data.append(info)
        print(
            f"  [{i}/{len(all_commit_shas)}] {sha[:8]} "
            f"{info['author']} - {info['comment'][:50]}"
        )

    # Write intermediate output
    with open(output_temp, "w", encoding="utf-8") as f:
        json.dump(commits_data, f, ensure_ascii=False, indent=2)
    print(f"\nIntermediate result saved to {output_temp}")

    # Step 3: Group by key (DI-xxx or full comment) and merge
    grouped: Dict[str, Dict] = defaultdict(
        lambda: {
            "key": "",
            "commit_ids": [],
            "comments": [],
            "files": set(),
            "total_changes": 0,
            "additions": 0,
            "deletions": 0,
        }
    )

    for commit in commits_data:
        key = extract_key(commit["comment"])
        grouped[key]["key"] = key
        grouped[key]["commit_ids"].append(commit["commit_id"])
        grouped[key]["comments"].append(commit["comment"])
        grouped[key]["files"].update(commit["files"])
        grouped[key]["total_changes"] += commit["total_changes"]
        grouped[key]["additions"] += commit["additions"]
        grouped[key]["deletions"] += commit["deletions"]

    # Build per-commit file map for diff extraction
    commit_file_map: Dict[str, List[str]] = {}
    for c in commits_data:
        commit_file_map[c["commit_id"]] = c["files"]

    result = []
    for key, data in grouped.items():
        entry = {
            "key": key,
            "repo": repo_url,
            "commit_ids": sorted(data["commit_ids"]),
            "comments": data["comments"],
            "files": sorted(data["files"]),
            "total_changes": data["total_changes"],
            "additions": data["additions"],
            "deletions": data["deletions"],
        }
        result.append(entry)

    # Step 4: Extract diffs for groups exceeding the threshold
    threshold = diff_threshold
    diff_count = 0

    for group in result:
        total = group["total_changes"]
        if total > 10000:
            continue
        if total <= threshold:
            continue
        print(
            f"Extracting diffs for '{group['key']}' ({total} lines changed, "
            f"{len(group['commit_ids'])} commits)"
        )
        diff_path = extract_diffs_for_group(
            repo_dir,
            diff_dir,
            group["key"],
            commit_file_map,
            group["commit_ids"],
        )
        group["diffPath"] = diff_path
        diff_count += 1

    if temp_dir:
        shutil.rmtree(temp_dir, ignore_errors=True)

    return result


def main() -> None:
    global VERBOSE

    parser = argparse.ArgumentParser(
        description="Aggregate git commits by users and branches"
    )
    parser.add_argument("repo_url", nargs="?", help="Git repository URL or local path")
    parser.add_argument(
        "--config",
        "-c",
        default=None,
        help="JSON config file for multi-repo mode (takes precedence over positional args)",
    )
    parser.add_argument(
        "--users",
        "-u",
        nargs="+",
        action='extend',
        required=False,
        help="Author names (or emails with --match-email) to filter commits",
    )
    parser.add_argument(
        "--branches",
        "-b",
        nargs="+",
        action='extend',
        required=False,
        help="Branches to analyze",
    )
    parser.add_argument(
        "--match-email",
        action="store_true",
        help="Match --users values against author email instead of author name",
    )
    parser.add_argument(
        "--list-authors",
        action="store_true",
        help="List all unique authors in the specified branches and exit",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Print debug information",
    )
    parser.add_argument(
        "--use-local",
        action="store_true",
        help="Use repo_url as an existing bare/non-bare repo directory (skip clone)",
    )
    parser.add_argument(
        "--diff-threshold",
        type=int,
        default=30,
        help="Extract before/after file versions when total_changes exceeds this (default: 50)",
    )
    parser.add_argument(
        "--diff-dir",
        default=None,
        help="Directory to store extracted diffs (default: <output_dir>/diffs)",
    )
    parser.add_argument(
        "--output-temp",
        default="output_temp.json",
        help="Temporary output file (default: output_temp.json)",
    )
    parser.add_argument(
        "--output",
        "-o",
        default="output.json",
        help="Final output file (default: output.json)",
    )
    parser.add_argument(
        "--repo-dir",
        help="Existing bare repo directory (skip clone). Deprecated, use --use-local.",
    )
    parser.add_argument(
        "--cache-dir",
        default=None,
        help="Directory to cache cloned repos (default: <script_dir>/.git_cache). Skips clone if repo already cached.",
    )
    args = parser.parse_args()

    VERBOSE = args.verbose

    # --- Multi-repo mode (--config) ---
    if args.config:
        with open(args.config, "r", encoding="utf-8") as f:
            config = json.load(f)
        repos = config.get("repos", [])
        users = config.get("users", [])
        if not repos:
            print("Error: 'repos' list is empty in config file.", file=sys.stderr)
            sys.exit(1)
        if not users:
            print("Error: 'users' list is empty in config file.", file=sys.stderr)
            sys.exit(1)

        # Global settings from CLI args (override config where applicable)
        match_email = config.get("match_email", args.match_email)
        diff_threshold = args.diff_threshold
        diff_dir = args.diff_dir or os.path.join(
            os.path.dirname(os.path.abspath(args.output)), "diffs"
        )
        cache_dir = args.cache_dir

        # --list-authors mode for multi-repo
        if args.list_authors:
            for idx, repo_cfg in enumerate(repos):
                repo_url = repo_cfg.get("repo_url", "")
                branches = repo_cfg.get("Branches", repo_cfg.get("branches", []))
                use_local = repo_cfg.get("use_local", False)
                if not repo_url or not branches:
                    continue
                repo_dir, temp_dir = resolve_repo_dir(repo_url, use_local, cache_dir)
                resolved_refs = []
                for branch in branches:
                    ref = resolve_branch_ref(repo_dir, branch)
                    if ref:
                        resolved_refs.append(ref)
                if not resolved_refs:
                    if temp_dir:
                        shutil.rmtree(temp_dir, ignore_errors=True)
                    continue
                authors = list_all_authors(repo_dir, resolved_refs)
                print(f"\nAuthors in '{repo_url}' ({len(authors)} total):")
                for a in authors:
                    print(f"  {a}")
                if temp_dir:
                    shutil.rmtree(temp_dir, ignore_errors=True)
            return

        all_results: List[Dict] = []
        temp_files: List[str] = []

        for idx, repo_cfg in enumerate(repos):
            repo_url = repo_cfg.get("repo_url", "")
            branches = repo_cfg.get("Branches", repo_cfg.get("branches", []))
            use_local = repo_cfg.get("use_local", False)

            if not repo_url:
                print(f"Warning: repo at index {idx} has no 'repo_url', skipping.", file=sys.stderr)
                continue
            if not branches:
                print(f"Warning: repo '{repo_url}' has no branches, skipping.", file=sys.stderr)
                continue

            print(f"\n{'='*60}")
            print(f"Processing repo [{idx+1}/{len(repos)}]: {repo_url}")
            print(f"  Branches: {branches}")
            print(f"{'='*60}")

            output_temp = f"output_temp_repo{idx}_{os.path.basename(args.output_temp)}"
            temp_files.append(output_temp)
            results = process_repo(
                repo_url=repo_url,
                branches=branches,
                users=users,
                match_email=match_email,
                use_local=use_local,
                diff_threshold=diff_threshold,
                diff_dir=diff_dir,
                output_temp=output_temp,
                cache_dir=cache_dir,
            )
            all_results.extend(results)

        # Merge results by key across repos
        merged: Dict[str, Dict] = defaultdict(
            lambda: {
                "key": "",
                "repos": [],
                "commit_ids": set(),
                "comments": [],
                "files": set(),
                "total_changes": 0,
                "additions": 0,
                "deletions": 0,
                "diffPaths": [],
            }
        )
        for entry in all_results:
            key = entry["key"]
            merged[key]["key"] = key
            if entry.get("repo") and entry["repo"] not in merged[key]["repos"]:
                merged[key]["repos"].append(entry["repo"])
            merged[key]["commit_ids"].update(entry.get("commit_ids", []))
            merged[key]["files"].update(entry.get("files", []))
            merged[key]["total_changes"] += entry.get("total_changes", 0)
            merged[key]["additions"] += entry.get("additions", 0)
            merged[key]["deletions"] += entry.get("deletions", 0)
            if entry.get("diffPath"):
                merged[key]["diffPaths"].append(entry["diffPath"])
            for comment in entry.get("comments", []):
                if comment not in merged[key]["comments"]:
                    merged[key]["comments"].append(comment)

        merged_results = []
        for key, data in merged.items():
            item = {
                "key": key,
                "repos": data["repos"],
                "commit_ids": sorted(data["commit_ids"]),
                "comments": data["comments"],
                "files": sorted(data["files"]),
                "total_changes": data["total_changes"],
                "additions": data["additions"],
                "deletions": data["deletions"],
            }
            if data["diffPaths"]:
                item["diffPaths"] = data["diffPaths"]
            merged_results.append(item)

        merged_results.sort(key=lambda x: x["key"])

        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(merged_results, f, ensure_ascii=False, indent=2)

        # Count diffs
        diff_count = sum(1 for g in merged_results if g.get("diffPaths"))
        print(
            f"\nMerged result saved to {args.output}  ({len(merged_results)} groups across {len(repos)} repos"
            + (f", {diff_count} diffs extracted)" if diff_count else ")")
        )

        # Clean up intermediate temp files
        for tf in temp_files:
            try:
                os.remove(tf)
            except OSError:
                pass
        return

    # --- Single-repo mode (positional args) ---
    if not args.repo_url:
        print("Error: repo_url is required. Use --config for multi-repo mode.", file=sys.stderr)
        sys.exit(1)
    if not args.users:
        print("Error: --users is required.", file=sys.stderr)
        sys.exit(1)
    if not args.branches:
        print("Error: --branches is required.", file=sys.stderr)
        sys.exit(1)

    # --list-authors mode (single repo only)
    if args.list_authors:
        repo_dir, temp_dir = resolve_repo_dir(args.repo_url, args.use_local, args.cache_dir, args.repo_dir)
        resolved_refs: List[str] = []
        for branch in args.branches:
            ref = resolve_branch_ref(repo_dir, branch)
            if ref:
                resolved_refs.append(ref)
            else:
                print(f"Warning: branch '{branch}' not found.", file=sys.stderr)
        if not resolved_refs:
            print("Error: no valid branches found.", file=sys.stderr)
            if temp_dir:
                shutil.rmtree(temp_dir, ignore_errors=True)
            sys.exit(1)
        authors = list_all_authors(repo_dir, resolved_refs)
        print(
            f"\nAll authors across branches {args.branches}: "
            f"({len(authors)} total)\n"
        )
        for a in authors:
            print(f"  {a}")
        if temp_dir:
            shutil.rmtree(temp_dir, ignore_errors=True)
        return

    diff_dir = args.diff_dir or os.path.join(
        os.path.dirname(os.path.abspath(args.output)), "diffs"
    )

    results = process_repo(
        repo_url=args.repo_url,
        branches=args.branches,
        users=args.users,
        match_email=args.match_email,
        use_local=args.use_local,
        diff_threshold=args.diff_threshold,
        diff_dir=diff_dir,
        output_temp=args.output_temp,
        cache_dir=args.cache_dir,
        repo_dir_override=args.repo_dir,
    )

    if not results:
        print("\nNo commits found matching the specified users.", file=sys.stderr)
        print(
            "Troubleshooting:\n"
            "  1. Run with --list-authors to see actual author names in the repo\n"
            "  2. Try --match-email if your --users values are email addresses\n"
            "  3. Use --verbose to see the git commands being executed",
            file=sys.stderr,
        )
        return

    results.sort(key=lambda x: x["key"])

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    diff_count = sum(1 for g in results if g.get("diffPath"))
    print(
        f"Merged result saved to {args.output}  ({len(results)} groups"
        + (f", {diff_count} diffs extracted)" if diff_count else ")")
    )


if __name__ == "__main__":
    main()
